//
//  ContentView.swift
//  Paisajes
//
//  Created by Alumno 17 on 10/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        PaisajeList()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
